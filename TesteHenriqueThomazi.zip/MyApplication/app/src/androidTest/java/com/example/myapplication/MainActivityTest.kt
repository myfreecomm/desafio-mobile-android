package com.example.myapplication

import org.junit.Test

import org.junit.Assert.*

class MainActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onCreateOptionsMenu() {
    }

    @Test
    fun onOptionsItemSelected() {
    }

    @Test
    fun getCart() {
    }

    @Test
    fun setList() {
    }

    @Test
    fun setLabels() {
    }

    @Test
    fun saveCart() {
    }

    @Test
    fun loadCart() {
    }
}