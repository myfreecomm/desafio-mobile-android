package com.example.myapplication

import android.app.ActionBar
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.model.CartItem
import com.example.myapplication.util.ImageUtil
import kotlinx.android.synthetic.main.content_details.*
import java.math.BigDecimal

class Details : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        setItemDetails()
    }


    override fun onSupportNavigateUp() : Boolean{
        onBackPressed()
        return true
    }

    fun setItemDetails(){
        //Carrega detalhes do item nos labels da tela

        if (intent.hasExtra("item")){
            val item = intent.extras?.get("item") as CartItem
            ImageUtil.loadImage(this, item_Image, item.image_url)
            label_item_description.setText(item.description)

            if (item.stock == 0){
                label_item_in_stock.setText("Out Of Stock")
            }else if (item.stock == 1){
                label_item_in_stock.setText("Only one left in stock")
            }else if (item.stock > 1){
                label_item_in_stock.setText("In Stock")
            }

            label_item_title.setText(item.name)
            label_item_price.setText("$"+item.price.toBigDecimal().setScale(2).div(BigDecimal(100)).toString())
        }else {
            finish()
        }

    }

    companion object {
        fun launchActivity(context: Context, item: CartItem?) {

            if (item == null) return Toast.makeText(context, R.string.item_load_failed, Toast.LENGTH_SHORT).show()
            val intent = Intent(context, Details::class.java)
            intent.putExtra("item", item)
            item.name?.let {
                intent.putExtra("title", "Product Details")
            }
            context.startActivity(intent)
        }
    }
}