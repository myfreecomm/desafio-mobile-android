package com.example.myapplication

import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapter.CartAdapter
import com.example.myapplication.apis.RetrofitManager
import com.example.myapplication.model.CartItem
import kotlinx.android.synthetic.main.content_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.*
import java.math.BigDecimal


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Cart"
        setSupportActionBar(findViewById(R.id.toolbar))
        getCart()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun getCart(){


        if (isNetworkAvailable()){
            val service = RetrofitManager.getRetrofit()
            CoroutineScope(Dispatchers.IO).launch {
                val response = service.getItems()
                withContext(Dispatchers.Main) {
                    try {
                        if (response.isSuccessful) {

                            saveCart(response.body() as ArrayList<CartItem>)
                            setList(response.body() as ArrayList<CartItem>)
                        } else {
                            //show toast
                            setList(loadCart())
                        }
                    } catch (e: HttpException) {
                        // toast("Exception ${e.message}")
                        Toast.makeText(applicationContext, "Ocorreu uma erro: " + e.message, Toast.LENGTH_SHORT).show()
                        setList(loadCart())
                    } catch (e: Throwable) {
                        // toast("Ooops: Something else went wrong")
                        Toast.makeText(applicationContext, "Ocorreu uma erro: " + e.localizedMessage, Toast.LENGTH_SHORT).show()
                        setList(loadCart())
                    }
                }
            }
        }else{
            setList(loadCart())
            Toast.makeText(applicationContext, "Conexão com a Internet Indisponível", Toast.LENGTH_SHORT).show()
        }


    }

    fun setList(list: ArrayList<CartItem>?){
        if (list != null){
            val somaSubtotal = list.sumBy { it.price }
            val somaShipping = list.sumBy { it.shipping }
            val somaTax = list.sumBy { it.tax }
            text_qtd_cart.text = "${list.size} ${getString(R.string.items_in_your_cart)}"
            setLabels(somaSubtotal, somaTax, somaShipping)
            val adapter = CartAdapter(this, list)
            list_cart.adapter = adapter
            list_cart.layoutManager = LinearLayoutManager(this)
        }
    }

    fun setLabels(subtotal: Int, tax: Int, shipping: Int){
        val formattedSubtotal = subtotal.toBigDecimal().setScale(2).div(BigDecimal(100))
        val formattedTax = tax.toBigDecimal().setScale(2).div(BigDecimal(100))
        val formattedShipping = shipping.toBigDecimal().setScale(2).div(BigDecimal(100))
        val formattedTotal = (formattedSubtotal + formattedTax + formattedShipping)

        //Set labels
        label_subvalue.setText("$"+formattedSubtotal.toString())
        label_taxvalue.setText("$"+formattedTax.toString())
        label_shippingvalue.setText("$"+formattedShipping.toString())
        label_value.setText("$"+formattedTotal.toString())


    }

    fun saveCart(toSave: ArrayList<CartItem>) {
        try {
            val file = File(getExternalFilesDir("cart"), "savedCart")
            ObjectOutputStream(FileOutputStream(file)).use { it -> it.writeObject(toSave) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun loadCart(): ArrayList<CartItem>? {
        var cart: ArrayList<CartItem> = ArrayList()
        try {
            val file = File(getExternalFilesDir("cart"), "savedCart")

            ObjectInputStream(FileInputStream(file)).use { it ->
                val objetoArquivo = it.readObject()
                cart = objetoArquivo as ArrayList<CartItem>
            }
            return cart
        } catch (e: IOException) {
            return null
        }
    }

    fun isNetworkAvailable(): Boolean {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null
    }

}