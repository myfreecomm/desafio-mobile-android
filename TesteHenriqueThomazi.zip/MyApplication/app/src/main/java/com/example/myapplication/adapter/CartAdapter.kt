package com.example.myapplication.adapter

import android.content.Context
import android.net.ConnectivityManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Details
import com.example.myapplication.R
import com.example.myapplication.model.CartItem
import com.example.myapplication.util.ImageUtil
import kotlinx.android.synthetic.main.card_item.view.*
import kotlinx.android.synthetic.main.content_details.view.*
import java.math.BigDecimal

class CartAdapter(private var context: Context, private var items: List<CartItem>): RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder (v: View): RecyclerView.ViewHolder(v) {
        var title = v.text_item_name
        var price = v.text_price
        var image = v.image_item
        var stock = v.text_stock_indicator
        var card = v.item_card

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.card_item, parent, false)
        return CartViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        var item = items.get(position)
        var listener = View.OnClickListener { view ->
            Details.launchActivity(context, item)
        }

        holder.card.setOnClickListener(listener)
        holder.title.setOnClickListener(listener)
        holder.price.setOnClickListener(listener)
        holder.image.setOnClickListener(listener)
        holder.stock.setOnClickListener(listener)

        holder.title.setText(item.name)
        holder.price.setText("$"+item.price.toBigDecimal().setScale(2).div(BigDecimal(100)).toString())

        if (item.stock == 0){
            holder.stock.setText("Out Of Stock")
        }else if (item.stock == 1){
            holder.stock.setText("Only one left in stock")
        }else if (item.stock > 1){
            holder.stock.setText("In Stock")
        }


        ImageUtil.loadImage(context, holder.image, item.image_url)

    }


}