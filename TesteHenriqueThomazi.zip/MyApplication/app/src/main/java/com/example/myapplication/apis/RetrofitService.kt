package com.example.myapplication.apis

import com.example.myapplication.model.CartItem
import retrofit2.Response
import retrofit2.http.GET

interface RetrofitService {

        @GET("data.json")
        suspend fun getItems(): Response<List<CartItem>>

}