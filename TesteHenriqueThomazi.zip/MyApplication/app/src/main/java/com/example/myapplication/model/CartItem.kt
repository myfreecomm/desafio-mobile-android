package com.example.myapplication.model

import java.io.Serializable

class CartItem(
     var name: String? = "",
     var quantity: Int = 0,
     var stock: Int =  0,
     var image_url:String? = "",
     var price: Int = 0,
     var tax: Int = 0,
     var shipping: Int = 0,
     var description: String? = ""
): Serializable {
}