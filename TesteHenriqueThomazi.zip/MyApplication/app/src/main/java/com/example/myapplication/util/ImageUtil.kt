package com.example.myapplication.util

import android.content.Context
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.example.myapplication.R

object ImageUtil {

    fun loadImage (context: Context, image: ImageView, url: String? ){
        Glide
            .with(context)
            .load(url)
            .centerCrop()
            .placeholder(android.R.drawable.ic_menu_gallery)
            .into(image);
    }
}